﻿# QUANTCONNECT.COM - Democratizing Finance, Empowering Individuals.
# Lean Algorithmic Trading Engine v2.0. Copyright 2014 QuantConnect Corporation.
# 
# Licensed under the Apache License, Version 2.0 (the "License"); 
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
# 
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from clr import AddReference
AddReference("System.Core")
AddReference("System.Collections")
AddReference("QuantConnect.Algorithm")
AddReference("QuantConnect.Common")

from System import *
from System.Linq import *
from QuantConnect import *
from QuantConnect.Algorithm import *
from QuantConnect.Data import *
from QuantConnect.Orders import *
from QuantConnect.Securities import *
from QuantConnect.Util import *
import decimal as d
from math import copysign
from datetime import datetime


class UpdateOrderRegressionAlgorithm(QCAlgorithm):
    '''Basic template algorithm simply initializes the date range and cash'''

    def Initialize(self):
        '''Initialise the data and resolution required, as well as the cash and start-end dates for your algorithm. All algorithms must initialized.'''
        
        self.SetStartDate(2013,01,01)  #Set Start Date
        self.SetEndDate(2015,01,01)    #Set End Date
        self.SetCash(100000)           #Set Strategy Cash
        # Find more symbols here: http://quantconnect.com/data

        self.security = self.AddEquity("SPY", Resolution.Daily)
        
        self.last_month = -1
        self.quantity = 100
        self.delta_quantity = 10

        self.stop_percentage = 0.025
        self.stop_percentage_delta = 0.005
        self.limit_percentage = 0.025
        self.limit_percentage_delta = 0.005

        OrderTypeEnum = [OrderType.Market, OrderType.Limit, OrderType.StopMarket, OrderType.StopLimit, OrderType.MarketOnOpen, OrderType.MarketOnClose]
        self.order_types_queue = CircularQueue[OrderType](OrderTypeEnum)
        self.order_types_queue.CircleCompleted += self.onCircleCompleted
        self.tickets = []


    def onCircleCompleted(self, sender, event):
        '''Flip our signs when we've gone through all the order types'''
        self.quantity *= -1
        

    def OnData(self, data):
        '''OnData event is the primary entry point for your algorithm. Each new data point will be pumped in here.'''
        if not data.ContainsKey("SPY"):
            return

        if self.Time.month != self.last_month:
            # we'll submit the next type of order from the queue
            orderType = self.order_types_queue.Dequeue();
            #Log("");
            self.Log("\r\n--------------MONTH: {0}:: {1}\r\n".format(self.Time.strftime("%B"), orderType))
            #Log("")
            self.last_month = self.Time.month
            self.Log("ORDER TYPE:: {0}".format(orderType))
            isLong = self.quantity > 0
            stopPrice = d.Decimal(1 + self.stop_percentage)*data["SPY"].High if isLong else d.Decimal(1 - self.stop_percentage)*data["SPY"].Low
            limitPrice = d.Decimal(1 - self.limit_percentage)*stopPrice if isLong else d.Decimal(1 + self.limit_percentage)*stopPrice
            
            if orderType == OrderType.Limit:
                limitPrice = d.Decimal(1 + self.limit_percentage)*data["SPY"].High if not isLong else d.Decimal(1 - self.limit_percentage)*data["SPY"].Low

            request = SubmitOrderRequest(orderType, self.security.Symbol.SecurityType, "SPY", self.quantity, stopPrice, limitPrice, self.Time, str(orderType))
            ticket = self.Transactions.AddOrder(request)
            self.tickets.append(ticket)

        elif len(self.tickets) > 0:
            ticket = self.tickets[-1]
                    
            if self.Time.day > 8 and self.Time.day < 14:
                if len(ticket.UpdateRequests) == 0 and ticket.Status is not OrderStatus.Filled:
                    self.Log("TICKET:: {0}".format(ticket))
                    updateOrderFields = UpdateOrderFields()
                    updateOrderFields.Quantity = ticket.Quantity + copysign(self.delta_quantity, self.quantity)
                    updateOrderFields.Tag = "Change quantity: {0}".format(self.Time)
                    ticket.Update(updateOrderFields)
                    
            elif self.Time.day > 13 and self.Time.day < 20:
                if len(ticket.UpdateRequests) == 1 and ticket.Status is not OrderStatus.Filled:
                    self.Log("TICKET:: {0}".format(ticket))
                    updateOrderFields = UpdateOrderFields()
                    updateOrderFields.LimitPrice = self.security.Price*d.Decimal(1 - copysign(self.limit_percentage_delta, ticket.Quantity))
                    updateOrderFields.StopPrice = self.security.Price*d.Decimal(1 + copysign(self.stop_percentage_delta, ticket.Quantity))
                    updateOrderFields.Tag = "Change prices: {0}".format(self.Time)
                    ticket.Update(updateOrderFields)
            else:
                if len(ticket.UpdateRequests) == 2 and ticket.Status is not OrderStatus.Filled:
                    self.Log("TICKET:: {0}".format(ticket))
                    ticket.Cancel("{0} and is still open!".format(self.Time))
                    self.Log("CANCELLED:: {0}".format(ticket.CancelRequest))


    def OnOrderEvent(self, orderEvent):
        if orderEvent.Status == OrderStatus.Filled:
            self.Log("FILLED:: {0} FILL PRICE:: {1}".format(self.Transactions.GetOrderById(orderEvent.OrderId), orderEvent.FillPrice))
        else:
            self.Log(orderEvent.ToString())
            self.Log("TICKET:: {0}".format(self.tickets[-1]))